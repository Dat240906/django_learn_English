


//mở vùng chứa comment 
document.querySelector('.opctncm').addEventListener('click', function (event) {
    const container_comment = document.querySelector('.container-total-comment')
    container_comment.style.display = "block"
})
//đóng vùng chứa comment
document.querySelector('.clctncm').addEventListener('click', function (event) {
    const container_comment = document.querySelector('.container-total-comment')
    container_comment.style.display = "none"
})