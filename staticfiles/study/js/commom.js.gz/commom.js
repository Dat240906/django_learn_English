
var notification = document.querySelector('.notification-js')
var message =document.querySelector(".notification-js p");
var background_color_fail = "#3E1927";
var color_fail  = "#F0879A";
var background_color_success = "#0a785b";
var color_success= "#95e8c5";



document.querySelector('.close-noti').addEventListener('click', function(){
    notification.style.display = 'none'
})
